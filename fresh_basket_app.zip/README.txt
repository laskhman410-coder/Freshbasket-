Fresh Basket demo web app
Upload index.html and manifest.json to your GitHub repository root.
Then enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root).
Edit sample vegetable prices in index.html before taking real orders.
